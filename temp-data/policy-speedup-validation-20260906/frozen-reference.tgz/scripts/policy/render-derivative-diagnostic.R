#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
source("R/policy/bootstrap.R")
parameter_csv <- policy_option_value(args, "--parameter-csv")
output_path <- policy_option_value(args, "--output-path")
num_draws <- as.integer(policy_option_value(args, "--num-draws", "100"))
if (is.null(parameter_csv) || is.null(output_path)) {
  stop("--parameter-csv and --output-path are required.", call. = FALSE)
}
if (!file.exists(parameter_csv)) stop("Missing parameter CSV: ", parameter_csv)

suppressPackageStartupMessages({
  library(dplyr)
  library(ggplot2)
})

parameters <- read.csv(parameter_csv, stringsAsFactors = FALSE)
required <- c(
  "draw", "beta_control", "beta_ink", "beta_calendar", "beta_bracelet",
  "dist_beta", "mu_control", "mu_ink", "mu_calendar", "mu_bracelet",
  "mu_dist_control", "mu_dist_ink", "mu_dist_calendar", "mu_dist_bracelet",
  "base_mu_rep", "u_sd", "sd_of_dist"
)
if (!all(required %in% names(parameters))) stop("Incomplete policy parameter CSV.")
if (any(!is.finite(as.matrix(parameters[required])))) {
  stop("Policy parameter CSV contains non-finite required values.")
}
draw_index <- unique(round(seq(1, nrow(parameters), length.out = min(num_draws, nrow(parameters)))))
parameters <- parameters[draw_index, , drop = FALSE]
treatments <- c("control", "ink", "calendar", "bracelet")
distances <- c(seq(0, 2500, length.out = 20), 3000, 4000, 5000)

delta_derivative <- function(cutoff, u_sd) {
  total_sd <- sqrt(1 + u_sd^2)
  probability <- pnorm(cutoff, sd = total_sd)
  density <- dnorm(cutoff, sd = total_sd)
  denominator <- pmax(probability * (1 - probability), .Machine$double.xmin)
  delta <- density / denominator
  delta * (-cutoff / total_sd^2 - density * (1 - 2 * probability) / denominator)
}

evaluate_arm <- function(parameter, treatment) {
  distance_sd <- distances / parameter$sd_of_dist
  arm_beta <- if (treatment == "control") 0 else parameter[[paste0("beta_", treatment)]]
  benefit <- parameter$beta_control + arm_beta - parameter$dist_beta * distance_sd
  mu <- policy_mu_rep(distance_sd, parameter, treatment)
  cutoff <- solve_policy_fixedpoint(benefit, mu, parameter$u_sd)
  latent_slope <- if (treatment == "control") {
    parameter$mu_dist_control
  } else {
    parameter$mu_dist_control + parameter[[paste0("mu_dist_", treatment)]]
  }
  mu_derivative <- mu * (1 - plogis(if (treatment == "control") {
    parameter$mu_control + parameter$mu_dist_control * distance_sd
  } else {
    parameter$mu_control + parameter[[paste0("mu_", treatment)]] +
      latent_slope * distance_sd
  })) * latent_slope
  delta <- policy_delta(cutoff, parameter$u_sd)
  denominator <- 1 + mu * delta_derivative(cutoff, parameter$u_sd)
  data.frame(
    draw = parameter$draw, distance = distances, treatment = treatment,
    derivative = (parameter$dist_beta - mu_derivative * delta) / denominator
  )
}

diagnostic <- bind_rows(lapply(seq_len(nrow(parameters)), function(index) {
  parameter <- as.list(parameters[index, , drop = FALSE])
  bind_rows(lapply(treatments, function(treatment) evaluate_arm(parameter, treatment)))
})) |>
  filter(is.finite(derivative)) |>
  mutate(treatment = factor(
    tools::toTitleCase(treatment), levels = c("Control", "Ink", "Calendar", "Bracelet")
  ))
if (!nrow(diagnostic)) stop("No finite derivative diagnostics were produced.")

plot <- ggplot(diagnostic, aes(derivative, fill = treatment)) +
  geom_histogram(bins = 30) +
  geom_vline(xintercept = 0, linetype = "longdash") +
  labs(x = "Derivative Value", y = "Count", fill = NULL) +
  theme_minimal() +
  theme(legend.position = "bottom") +
  ggthemes::scale_fill_canva(palette = "Primary colors with a vibrant twist")

dir.create(output_path, recursive = TRUE, showWarnings = FALSE)
ggsave(
  file.path(output_path, "dydc-derivative-positive-check.pdf"),
  plot, width = 8, height = 6
)
write.csv(diagnostic, file.path(output_path, "dydc-derivative-positive-check.csv"), row.names = FALSE)
write.csv(data.frame(
  parameter_csv = normalizePath(parameter_csv), draws = length(draw_index),
  evaluations = nrow(diagnostic), share_positive = mean(diagnostic$derivative > 0),
  generated_utc = format(Sys.time(), tz = "UTC", usetz = TRUE)
), file.path(output_path, "dydc-derivative-positive-check-manifest.csv"), row.names = FALSE)
